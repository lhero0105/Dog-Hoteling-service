package com.green.hoteldog.dog.models;

import lombok.Data;

@Data
public class DelUserDogDto {
    private int userPk;
    private int userDogPk;
}
