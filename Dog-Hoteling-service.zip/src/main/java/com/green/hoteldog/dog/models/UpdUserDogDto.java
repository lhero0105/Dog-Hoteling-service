package com.green.hoteldog.dog.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import org.springframework.web.multipart.MultipartFile;

@Data
public class UpdUserDogDto {
    private int userPk;
    private int userDogPk;
    private int sizePk;
    private String dogNm;
    private int dogAge;
    @JsonIgnore
    private MultipartFile dogPic;
    private String dogEtc;
}
