package com.green.hoteldog.reservation.model;

import lombok.Data;

@Data
public class ResInfoDto {
    private int userPk;
}
//승준