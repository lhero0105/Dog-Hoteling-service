package com.green.hoteldog.reservation.model;

import lombok.Data;

@Data
public class ResInfoProcDto {
    private int resPk;
    private int userPk;
}
//승준