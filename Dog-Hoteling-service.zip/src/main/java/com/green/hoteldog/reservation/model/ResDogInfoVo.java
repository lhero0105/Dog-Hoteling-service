package com.green.hoteldog.reservation.model;

import lombok.Data;

@Data
public class ResDogInfoVo {
    private int resPk;
    private String dogNm;
}
//승준