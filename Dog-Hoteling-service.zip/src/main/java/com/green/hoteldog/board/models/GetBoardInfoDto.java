package com.green.hoteldog.board.models;

import lombok.Data;

@Data
public class GetBoardInfoDto {
    private int boardPk;

}
