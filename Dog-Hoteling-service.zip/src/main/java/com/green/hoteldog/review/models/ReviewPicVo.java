package com.green.hoteldog.review.models;

import lombok.Data;

@Data
public class ReviewPicVo {
    private int reviewPk;
    private String pic;
}
