package com.green.hoteldog.review.models;

import lombok.Data;

@Data
public class ReviewFavDto {
    private int userPk;
    private int reviewPk;
}
