package com.green.hoteldog.review.models;

import lombok.Data;

//영웅
@Data
public class HotelReviewPicsSelVo {
    private int reviewPk;
    private String pic;
}
