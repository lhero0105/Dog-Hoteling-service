package com.green.hoteldog.email;

import lombok.Data;

@Data
public class EmailResponseVo {
    private String email;
    private int result;
}
