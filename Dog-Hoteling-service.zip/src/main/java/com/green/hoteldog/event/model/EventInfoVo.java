package com.green.hoteldog.event.model;

import lombok.Data;


@Data
public class EventInfoVo {
    private String pic;
    private String url;
}
//승준
