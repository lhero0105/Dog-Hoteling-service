package com.green.hoteldog.user.models;

import lombok.Data;

@Data
public class UserHotelFavDto {
}
