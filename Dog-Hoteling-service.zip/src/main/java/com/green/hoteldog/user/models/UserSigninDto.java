package com.green.hoteldog.user.models;

import lombok.Data;

@Data
public class UserSigninDto {
    private String userEmail;
    private String upw;
}
