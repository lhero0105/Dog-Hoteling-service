package com.green.hoteldog.common;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class ResVo {
    private int result;
}