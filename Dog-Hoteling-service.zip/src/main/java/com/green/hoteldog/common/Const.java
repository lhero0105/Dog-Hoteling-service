package com.green.hoteldog.common;

public class Const {

}