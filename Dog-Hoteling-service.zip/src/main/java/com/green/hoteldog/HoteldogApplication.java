package com.green.hoteldog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HoteldogApplication {

    public static void main(String[] args) {
        SpringApplication.run(HoteldogApplication.class, args);
    }

}
