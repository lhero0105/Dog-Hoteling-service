package com.green.hoteldog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HoteldogApplicationTests {

    @Test
    void contextLoads() {
    }

}
